
router.post('/leave', async (req, res) => {
    const { slotNumber } = req.body;
    try {
        const parkingSlot = await ParkingSlot.findOne({ slotNumber });
        if (!parkingSlot) {
            return res.status(404).json({ error: 'Slot not found' });
        }
        parkingSlot.registrationNumber = null;
        parkingSlot.color = null;
        parkingSlot.isOccupied = false;
        await parkingSlot.save();
        res.status(200).json({ message: 'Car left parking lot successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to leave parking lot' });
    }
});
