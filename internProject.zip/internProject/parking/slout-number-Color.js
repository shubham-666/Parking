
router.get('./slout-number-Color.js', async (req, res) => {
    const { color } = req.params;
    try {
        const slotNumbers = await ParkingSlot.find({ color }).distinct('slotNumber');
        res.status(200).json(slotNumbers);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch slot numbers' });
    }
});
