
router.post('/create', async (req, res) => {
    const { capacity } = req.body;
    try {
        const parkingLot = new ParkingLot({ capacity });
        await parkingLot.save();
        res.status(201).json({ message: 'Parking lot created successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to create parking lot' });
    }
});
