
router.post('/park', async (req, res) => {
    const { registrationNumber, color } = req.body;
    try {
        const parkingSlot = await ParkingSlot.findOne({ isOccupied: false });
        if (!parkingSlot) {
            return res.status(400).json({ error: 'Parking lot is full' });
        }
        parkingSlot.registrationNumber = registrationNumber;
        parkingSlot.color = color;
        parkingSlot.isOccupied = true;
        await parkingSlot.save();
        res.status(201).json({ message: 'Car parked successfully', slotNumber: parkingSlot.slotNumber });
    } catch (error) {
        res.status(500).json({ error: 'Failed to park car' });
    }
});
