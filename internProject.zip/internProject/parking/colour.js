
router.get('/registrationNumbers/:color', async (req, res) => {
    const { color } = req.params;
    try {
        const registrationNumbers = await ParkingSlot.find({ color }).distinct('registrationNumber');
        res.status(200).json(registrationNumbers);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch registration numbers' });
    }
});
