const express = require('express');
const ParkingSlot = require('.parkingSlot');

const router = express.Router();


router.post('/create', async (req, res) => {
  
});


router.post('/park', async (req, res) => {
 
});


router.post('/leave', async (req, res) => {
 
});

router.get('../registrationNumbers/:color', async (req, res) => {
  
});


router.get('/slotNumbers/:color', async (req, res) => {
  
});

module.exports = router;
