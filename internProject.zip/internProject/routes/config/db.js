const mongoose = require('mongoose');

mongoose.Promise = global.Promise;

mongoose.connection.on('error', (err) => {
  console.error(`MongoDB connection error: ${err}`);
  process.exit(1);
});

module.exports = {
  connect: (uri) => {
    mongoose.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
    });
  },
  close: () => mongoose.connection.close(),
};
